<?php

class Talent_Search_AJAX {

    public function __construct() {
        add_action( 'wp_ajax_talent_search_filter', array( $this, 'filter_talents' ) );
        add_action( 'wp_ajax_nopriv_talent_search_filter', array( $this, 'filter_talents' ) );
        add_action( 'wp_ajax_talent_search_get_filters', array( $this, 'get_filters' ) );
        add_action( 'wp_ajax_nopriv_talent_search_get_filters', array( $this, 'get_filters' ) );
    }

    /**
     * Récupère les filtres disponibles (taxonomies et termes)
     */
    public function get_filters() {
        check_ajax_referer( 'talent_search_nonce', 'nonce' );

        $filters = array();
        $taxonomies = get_object_taxonomies( 'talent', 'objects' );

        // Filtrer seulement les taxonomies qu'on veut afficher
        $allowed_taxonomies = array( 'sport_category', 'country', 'city', 'age_group' );

        foreach ( $taxonomies as $taxonomy ) {
            if ( ! in_array( $taxonomy->name, $allowed_taxonomies ) ) {
                continue;
            }

            $terms = get_terms( array(
                'taxonomy'   => $taxonomy->name,
                'hide_empty' => false,
                'orderby'    => 'name',
                'order'      => 'ASC',
            ) );

            if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
                $filters[ $taxonomy->name ] = array(
                    'label' => $taxonomy->label,
                    'terms' => array_map( function( $term ) {
                        return array(
                            'id'   => $term->term_id,
                            'name' => $term->name,
                            'slug' => $term->slug,
                        );
                    }, $terms ),
                );
            }
        }

        wp_send_json_success( $filters );
    }

    /**
     * Filtre les talents selon les critères
     */
    public function filter_talents() {
        check_ajax_referer( 'talent_search_nonce', 'nonce' );

        $search = sanitize_text_field( $_POST['search'] ?? '' );
        $filters = isset( $_POST['filters'] ) ? array_map( 'intval', $_POST['filters'] ) : array();
        $paged = absint( $_POST['paged'] ?? 1 );
        $posts_per_page = 10;

        // Construction de la requête
        $args = array(
            'post_type'      => 'talent',
            'posts_per_page' => $posts_per_page,
            'paged'          => $paged,
            's'              => $search,
            'orderby'        => 'date',
            'order'          => 'DESC',
        );

        // Ajout des filtres de taxonomies
        if ( ! empty( $filters ) ) {
            $tax_query = array( 'relation' => 'AND' );

            foreach ( $filters as $filter_id ) {
                $term = get_term( $filter_id );
                if ( $term && ! is_wp_error( $term ) ) {
                    $tax_query[] = array(
                        'taxonomy' => $term->taxonomy,
                        'field'    => 'term_id',
                        'terms'    => $filter_id,
                    );
                }
            }

            if ( count( $tax_query ) > 1 ) {
                $args['tax_query'] = $tax_query;
            }
        }

        $query = new WP_Query( $args );

        ob_start();

        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                include TALENT_SEARCH_PATH . 'templates/talent-card.php';
            }
        } else {
            echo '<div class="talent-no-results">';
            echo '<p>' . __( 'Aucun talent trouvé', 'talent-search' ) . '</p>';
            echo '</div>';
        }

        $output = ob_get_clean();
        wp_reset_postdata();

        wp_send_json_success( array(
            'html'       => $output,
            'total'      => $query->found_posts,
            'max_pages'  => $query->max_num_pages,
            'current_page' => $paged,
        ) );
    }
}