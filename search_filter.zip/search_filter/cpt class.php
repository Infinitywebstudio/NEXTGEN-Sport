<?php

class Talent_Search_CPT {

    public function __construct() {
        add_action( 'init', array( $this, 'register_post_type' ) );
        add_action( 'init', array( $this, 'register_taxonomies' ) );
    }

    public function register_post_type() {
        $labels = array(
            'name'               => __( 'Talents', 'talent-search' ),
            'singular_name'      => __( 'Talent', 'talent-search' ),
            'menu_name'          => __( 'Talents', 'talent-search' ),
            'all_items'          => __( 'Tous les talents', 'talent-search' ),
            'add_new_item'       => __( 'Ajouter un talent', 'talent-search' ),
            'edit_item'          => __( 'Modifier le talent', 'talent-search' ),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'talent' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 5,
            'menu_icon'          => 'dashicons-star-filled',
            'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        );

        register_post_type( 'talent', $args );
    }

    public function register_taxonomies() {
        // Taxonomies de base
        $taxonomies = array(
            'sport_category' => array(
                'label'       => __( 'Sport', 'talent-search' ),
                'description' => __( 'Catégories de sports', 'talent-search' ),
            ),
            'country' => array(
                'label'       => __( 'Pays', 'talent-search' ),
                'description' => __( 'Pays disponibles', 'talent-search' ),
            ),
            'city' => array(
                'label'       => __( 'Ville', 'talent-search' ),
                'description' => __( 'Villes disponibles', 'talent-search' ),
            ),
            'age_group' => array(
                'label'       => __( 'Groupe d\'âge', 'talent-search' ),
                'description' => __( 'Groupes d\'âge', 'talent-search' ),
            ),
        );

        foreach ( $taxonomies as $taxonomy => $config ) {
            register_taxonomy(
                $taxonomy,
                'talent',
                array(
                    'labels'            => array(
                        'name'          => $config['label'],
                        'singular_name' => $config['label'],
                    ),
                    'description'       => $config['description'],
                    'public'            => true,
                    'publicly_queryable' => true,
                    'show_ui'           => true,
                    'show_in_menu'      => true,
                    'show_in_rest'      => true,
                    'hierarchical'      => false,
                    'rewrite'           => array( 'slug' => $taxonomy ),
                )
            );
        }
    }
}