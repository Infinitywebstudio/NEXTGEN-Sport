<?php

class Talent_Search_Demo_Data {

    public function __construct() {
        $this->create_demo_data();
    }

    public function create_demo_data() {
        // Vérifier si les données de démo existent déjà
        if ( get_option( 'talent_search_demo_created' ) ) {
            return;
        }

        // Créer les termes des taxonomies
        $sports = array( 'Football', 'Basketball', 'Tennis', 'Volleyball', 'Athlétisme' );
        $countries = array( 'France', 'Italie', 'Espagne', 'Allemagne', 'Belgique', 'Suisse' );
        $cities = array( 'Paris', 'Lyon', 'Marseille', 'Milan', 'Rome', 'Madrid', 'Berlin' );
        $ages = array( '12-14 ans', '15-17 ans', '18-21 ans', '22-25 ans', '+25 ans' );

        // Insérer les sports
        foreach ( $sports as $sport ) {
            wp_insert_term( $sport, 'sport_category' );
        }

        // Insérer les pays
        foreach ( $countries as $country ) {
            wp_insert_term( $country, 'country' );
        }

        // Insérer les villes
        foreach ( $cities as $city ) {
            wp_insert_term( $city, 'city' );
        }

        // Insérer les groupes d'âge
        foreach ( $ages as $age ) {
            wp_insert_term( $age, 'age_group' );
        }

        // Créer des talents de démo
        $talents_data = array(
            array(
                'title'   => 'Jean Dupont',
                'content' => 'Jeune talent prometteur en football, actuellement en formation.',
                'sports'  => array( 'Football' ),
                'countries' => array( 'France' ),
                'cities'  => array( 'Paris' ),
                'ages'    => array( '18-21 ans' ),
            ),
            array(
                'title'   => 'Marie Martin',
                'content' => 'Joueuse de tennis talentueuse avec expérience en compétitions nationales.',
                'sports'  => array( 'Tennis' ),
                'countries' => array( 'France' ),
                'cities'  => array( 'Lyon' ),
                'ages'    => array( '15-17 ans' ),
            ),
            array(
                'title'   => 'Marco Rossi',
                'content' => 'Athlète italien spécialisé en saut en hauteur, médaillé en compétitions régionales.',
                'sports'  => array( 'Athlétisme' ),
                'countries' => array( 'Italie' ),
                'cities'  => array( 'Milan' ),
                'ages'    => array( '22-25 ans' ),
            ),
            array(
                'title'   => 'Anna Schmidt',
                'content' => 'Joueuse de volleyball allemande avec grande expérience en club.',
                'sports'  => array( 'Volleyball' ),
                'countries' => array( 'Allemagne' ),
                'cities'  => array( 'Berlin' ),
                'ages'    => array( '22-25 ans' ),
            ),
            array(
                'title'   => 'Carlos García',
                'content' => 'Jeune joueur de basketball espagnol en développement constant.',
                'sports'  => array( 'Basketball' ),
                'countries' => array( 'Espagne' ),
                'cities'  => array( 'Madrid' ),
                'ages'    => array( '18-21 ans' ),
            ),
            array(
                'title'   => 'Sophie Lefevre',
                'content' => 'Footballeuse avec expérience en championnat de France féminin.',
                'sports'  => array( 'Football' ),
                'countries' => array( 'France' ),
                'cities'  => array( 'Marseille' ),
                'ages'    => array( '22-25 ans' ),
            ),
            array(
                'title'   => 'Lucas Moreau',
                'content' => 'Jeune basketteur avec potentiel de progression rapide.',
                'sports'  => array( 'Basketball' ),
                'countries' => array( 'France' ),
                'cities'  => array( 'Paris' ),
                'ages'    => array( '15-17 ans' ),
            ),
            array(
                'title'   => 'Elena Bianchi',
                'content' => 'Joueuse de tennis italienne, prometteur talent junior.',
                'sports'  => array( 'Tennis' ),
                'countries' => array( 'Italie' ),
                'cities'  => array( 'Rome' ),
                'ages'    => array( '12-14 ans' ),
            ),
            array(
                'title'   => 'Thomas Petite',
                'content' => 'Athlète belge spécialisé en sprint et sauts.',
                'sports'  => array( 'Athlétisme' ),
                'countries' => array( 'Belgique' ),
                'cities'  => array( 'Bruxelles' ),
                'ages'    => array( '18-21 ans' ),
            ),
            array(
                'title'   => 'Giuliana Conti',
                'content' => 'Volleyleuse italienne avec expérience en compétitions régionales.',
                'sports'  => array( 'Volleyball' ),
                'countries' => array( 'Italie' ),
                'cities'  => array( 'Milan' ),
                'ages'    => array( '22-25 ans' ),
            ),
        );

        foreach ( $talents_data as $talent ) {
            $post_id = wp_insert_post( array(
                'post_type'    => 'talent',
                'post_title'   => $talent['title'],
                'post_content' => $talent['content'],
                'post_status'  => 'publish',
            ) );

            if ( $post_id ) {
                // Ajouter les taxonomies
                wp_set_object_terms( $post_id, $talent['sports'], 'sport_category' );
                wp_set_object_terms( $post_id, $talent['countries'], 'country' );
                wp_set_object_terms( $post_id, $talent['cities'], 'city' );
                wp_set_object_terms( $post_id, $talent['ages'], 'age_group' );
            }
        }

        // Marquer les données de démo comme créées
        update_option( 'talent_search_demo_created', true );
    }
}