/**
 * Talent Search System - JavaScript principal
 */

(function() {
    'use strict';

    const app = {
        config: {
            ajaxUrl: talentSearch.ajaxUrl,
            nonce: talentSearch.nonce,
            postsPerPage: 10,
        },

        state: {
            selectedFilters: [],
            currentPage: 1,
            maxPages: 1,
            isLoading: false,
            searchTerm: '',
            debounceTimer: null,
        },

        elements: {
            searchInput: null,
            filtersContainer: null,
            resultsContainer: null,
            loadMoreBtn: null,
            resultsCount: null,
            pagination: null,
        },

        /**
         * Initialisation
         */
        init: function() {
            this.cacheElements();
            this.bindEvents();
            this.loadFilters();
            this.loadTalents();
        },

        /**
         * Cache les éléments du DOM
         */
        cacheElements: function() {
            this.elements.searchInput = document.getElementById('talent-search-input');
            this.elements.filtersContainer = document.getElementById('talent-filters');
            this.elements.resultsContainer = document.getElementById('talent-results');
            this.elements.loadMoreBtn = document.getElementById('talent-load-more');
            this.elements.resultsCount = document.getElementById('talent-results-count');
            this.elements.pagination = document.getElementById('talent-pagination');
        },

        /**
         * Lie les événements
         */
        bindEvents: function() {
            // Recherche avec debounce
            this.elements.searchInput.addEventListener('input', (e) => {
                this.handleSearch(e);
            });

            // Bouton "Voir tout"
            this.elements.loadMoreBtn.addEventListener('click', () => {
                this.loadMoreTalents();
            });

            // Filtres (event delegation)
            this.elements.filtersContainer.addEventListener('change', (e) => {
                if (e.target.type === 'checkbox') {
                    this.handleFilterChange(e);
                }
            });
        },

        /**
         * Gère la recherche avec debounce
         */
        handleSearch: function(e) {
            this.state.searchTerm = e.target.value;
            this.state.currentPage = 1;

            clearTimeout(this.state.debounceTimer);
            this.state.debounceTimer = setTimeout(() => {
                this.loadTalents();
            }, 300); // Attendre 300ms après la dernière frappe
        },

        /**
         * Gère le changement de filtre
         */
        handleFilterChange: function(e) {
            const checkbox = e.target;
            const filterId = parseInt(checkbox.value);

            if (checkbox.checked) {
                if (!this.state.selectedFilters.includes(filterId)) {
                    this.state.selectedFilters.push(filterId);
                }
            } else {
                this.state.selectedFilters = this.state.selectedFilters.filter(f => f !== filterId);
            }

            this.state.currentPage = 1;
            this.loadTalents();
        },

        /**
         * Charge les filtres disponibles
         */
        loadFilters: function() {
            fetch(this.config.ajaxUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: this.buildFormData({
                    action: 'talent_search_get_filters',
                    nonce: this.config.nonce,
                }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.renderFilters(data.data);
                }
            })
            .catch(error => console.error('Erreur lors du chargement des filtres:', error));
        },

        /**
         * Affiche les filtres
         */
        renderFilters: function(filters) {
            let html = '';

            Object.keys(filters).forEach(taxonomy => {
                const filter = filters[taxonomy];
                html += `
                    <div class="talent-filter-group">
                        <label class="talent-filter-label">${this.escapeHtml(filter.label)}</label>
                        <ul class="talent-filter-options">
                `;

                filter.terms.forEach(term => {
                    html += `
                        <li class="talent-filter-option">
                            <input 
                                type="checkbox" 
                                id="filter-${term.id}" 
                                value="${term.id}" 
                                data-taxonomy="${taxonomy}"
                            >
                            <label for="filter-${term.id}">${this.escapeHtml(term.name)}</label>
                        </li>
                    `;
                });

                html += `
                        </ul>
                    </div>
                `;
            });

            this.elements.filtersContainer.innerHTML = html;
        },

        /**
         * Charge les talents
         */
        loadTalents: function() {
            if (this.state.isLoading) return;

            this.state.isLoading = true;
            this.elements.resultsContainer.innerHTML = '<div class="talent-loading"><p>Chargement...</p></div>';

            fetch(this.config.ajaxUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: this.buildFormData({
                    action: 'talent_search_filter',
                    nonce: this.config.nonce,
                    search: this.state.searchTerm,
                    filters: this.state.selectedFilters,
                    paged: this.state.currentPage,
                }),
            })
            .then(response => response.json())
            .then(data => {
                this.state.isLoading = false;

                if (data.success) {
                    this.renderTalents(data.data);
                }
            })
            .catch(error => {
                this.state.isLoading = false;
                console.error('Erreur lors du chargement des talents:', error);
            });
        },

        /**
         * Affiche les résultats des talents
         */
        renderTalents: function(data) {
            this.elements.resultsContainer.innerHTML = data.html;

            // Mettre à jour le compteur
            this.elements.resultsCount.textContent = `${data.total} résultat${data.total > 1 ? 's' : ''}`;

            // Gérer le bouton "Voir tout" / "Charger plus"
            if (data.max_pages > 1 && data.current_page < data.max_pages) {
                this.elements.pagination.style.display = 'flex';
                this.elements.loadMoreBtn.textContent = data.current_page === 1 ? 'Voir tout' : 'Charger plus';
            } else {
                this.elements.pagination.style.display = 'none';
            }
        },

        /**
         * Charge plus de talents
         */
        loadMoreTalents: function() {
            this.state.currentPage++;
            this.loadTalents();
        },

        /**
         * Crée un formulaire encodé pour fetch
         */
        buildFormData: function(data) {
            return Object.keys(data)
                .map(key => {
                    if (Array.isArray(data[key])) {
                        return data[key]
                            .map(val => `${encodeURIComponent(key)}[]=${encodeURIComponent(val)}`)
                            .join('&');
                    }
                    return `${encodeURIComponent(key)}=${encodeURIComponent(data[key])}`;
                })
                .join('&');
        },

        /**
         * Échappe les caractères HTML
         */
        escapeHtml: function(text) {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, m => map[m]);
        },
    };

    // Initialiser au chargement du DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => app.init());
    } else {
        app.init();
    }

    // Exposer l'app (optionnel, pour le debug)
    window.talentSearchApp = app;
})();