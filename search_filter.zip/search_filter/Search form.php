<?php
// Récupérer les données de test (au premier chargement)
new Talent_Search_Demo_Data();
?>

<div class="talent-search-wrapper">
    <!-- Barre de recherche générale -->
    <div class="talent-search-header">
        <input 
            type="text" 
            id="talent-search-input" 
            class="talent-search-input" 
            placeholder="Rechercher un talent (nom, description, sport...)"
            autocomplete="off"
        >
    </div>

    <!-- Filtres -->
    <div class="talent-filters-container">
        <div id="talent-filters-loader" class="talent-filters-loader">
            <p><?php _e( 'Chargement des filtres...', 'talent-search' ); ?></p>
        </div>
        <div id="talent-filters" class="talent-filters"></div>
    </div>

    <!-- Résultats -->
    <div class="talent-results-section">
        <div class="talent-results-header">
            <h3 class="talent-results-title"><?php _e( 'Talents disponibles', 'talent-search' ); ?></h3>
            <span id="talent-results-count" class="talent-results-count"></span>
        </div>

        <div id="talent-results" class="talent-results-grid">
            <div class="talent-loading">
                <p><?php _e( 'Chargement des talents...', 'talent-search' ); ?></p>
            </div>
        </div>

        <!-- Bouton Voir tout / Charger plus -->
        <div id="talent-pagination" class="talent-pagination" style="display: none;">
            <button id="talent-load-more" class="talent-load-more-btn">
                <?php _e( 'Voir tout', 'talent-search' ); ?>
            </button>
        </div>
    </div>
</div>