<?php
/**
 * Plugin Name: Talent Search System
 * Description: Système de recherche et filtrage de talents sportifs
 * Version: 1.0
 * Author: Infinity Studio
 * Text Domain: talent-search
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Constantes
define( 'TALENT_SEARCH_PATH', plugin_dir_path( __FILE__ ) );
define( 'TALENT_SEARCH_URL', plugin_dir_url( __FILE__ ) );
define( 'TALENT_SEARCH_VERSION', '1.0' );

// Chargement des fichiers principaux
require_once TALENT_SEARCH_PATH . 'includes/class-cpt.php';
require_once TALENT_SEARCH_PATH . 'includes/class-ajax.php';
require_once TALENT_SEARCH_PATH . 'includes/class-demo-data.php';

// Initialisation
add_action( 'plugins_loaded', function() {
    new Talent_Search_CPT();
    new Talent_Search_AJAX();
} );

// Enregistrement des scripts et styles
add_action( 'wp_enqueue_scripts', function() {
    wp_enqueue_style(
        'talent-search-style',
        TALENT_SEARCH_URL . 'assets/css/style.css',
        array(),
        TALENT_SEARCH_VERSION
    );

    wp_enqueue_script(
        'talent-search-script',
        TALENT_SEARCH_URL . 'assets/js/search.js',
        array(),
        TALENT_SEARCH_VERSION,
        true
    );

    wp_localize_script( 'talent-search-script', 'talentSearch', array(
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce' => wp_create_nonce( 'talent_search_nonce' ),
    ) );

    // Import Google Fonts - Inter
    wp_enqueue_style(
        'google-fonts-inter',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
        array(),
        null
    );
} );

// Création des données de démo à l'activation
register_activation_hook( __FILE__, function() {
    new Talent_Search_Demo_Data();
} );

// Shortcode pour afficher le système de recherche
add_shortcode( 'talent_search', function() {
    return include TALENT_SEARCH_PATH . 'templates/search-form.php';
} );