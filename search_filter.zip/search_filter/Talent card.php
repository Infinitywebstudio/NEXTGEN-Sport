<?php
$talent_id = get_the_ID();
$sports = wp_get_post_terms( $talent_id, 'sport_category', array( 'fields' => 'names' ) );
$countries = wp_get_post_terms( $talent_id, 'country', array( 'fields' => 'names' ) );
$cities = wp_get_post_terms( $talent_id, 'city', array( 'fields' => 'names' ) );
$ages = wp_get_post_terms( $talent_id, 'age_group', array( 'fields' => 'names' ) );
?>

<article class="talent-card">
    <div class="talent-card-header">
        <div class="talent-card-title-section">
            <h4 class="talent-card-title"><?php the_title(); ?></h4>
            <?php if ( ! empty( $sports ) && ! is_wp_error( $sports ) ) : ?>
                <div class="talent-card-sports">
                    <?php foreach ( $sports as $sport ) : ?>
                        <span class="talent-tag talent-tag-sport"><?php echo esc_html( $sport ); ?></span>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="talent-card-body">
        <p class="talent-card-excerpt"><?php echo wp_trim_words( get_the_excerpt() ?: get_the_content(), 20 ); ?></p>
    </div>

    <div class="talent-card-footer">
        <div class="talent-card-info">
            <?php if ( ! empty( $countries ) && ! is_wp_error( $countries ) ) : ?>
                <div class="talent-card-info-item">
                    <span class="talent-info-label"><?php _e( 'Pays:', 'talent-search' ); ?></span>
                    <span class="talent-info-value"><?php echo esc_html( implode( ', ', $countries ) ); ?></span>
                </div>
            <?php endif; ?>

            <?php if ( ! empty( $cities ) && ! is_wp_error( $cities ) ) : ?>
                <div class="talent-card-info-item">
                    <span class="talent-info-label"><?php _e( 'Ville:', 'talent-search' ); ?></span>
                    <span class="talent-info-value"><?php echo esc_html( implode( ', ', $cities ) ); ?></span>
                </div>
            <?php endif; ?>

            <?php if ( ! empty( $ages ) && ! is_wp_error( $ages ) ) : ?>
                <div class="talent-card-info-item">
                    <span class="talent-info-label"><?php _e( 'Âge:', 'talent-search' ); ?></span>
                    <span class="talent-info-value"><?php echo esc_html( implode( ', ', $ages ) ); ?></span>
                </div>
            <?php endif; ?>
        </div>

        <a href="<?php the_permalink(); ?>" class="talent-card-link">
            <?php _e( 'Voir le profil', 'talent-search' ); ?> &rarr;
        </a>
    </div>
</article>